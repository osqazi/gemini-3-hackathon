"""
Core Package for RecipeRAG
Contains core functionality modules
"""