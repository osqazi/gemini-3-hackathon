"""
Unit tests package for the RecipeRAG Gemini Agent feature.

Contains unit tests for individual components and services.
"""