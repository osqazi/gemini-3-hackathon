"""
Integration tests package for the RecipeRAG Gemini Agent feature.

Contains integration tests for API endpoints and cross-component functionality.
"""