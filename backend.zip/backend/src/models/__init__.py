"""
Models package for the RecipeRAG Gemini Agent feature.

Contains session management and data models for the conversational chef agent.
"""