"""
Services package for the RecipeRAG Gemini Agent feature.

Contains business logic for Gemini chat integration, RAG, and other services.
"""