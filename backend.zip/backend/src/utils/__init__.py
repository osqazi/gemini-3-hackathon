"""
Utils package for the RecipeRAG Gemini Agent feature.

Contains utility functions for response parsing and other helper functions.
"""