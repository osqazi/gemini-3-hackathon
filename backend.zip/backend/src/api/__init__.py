"""
API package for the RecipeRAG Gemini Agent feature.

Contains API routers and endpoint definitions for the chat functionality.
"""