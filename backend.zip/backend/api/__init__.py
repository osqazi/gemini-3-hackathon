"""
API Package for RecipeRAG
Root package for API modules
"""